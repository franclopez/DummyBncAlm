//Datos quemados de la app para pruebas de diseno y concepto

//angular.module('appalm.factories2', [])


